# Gantt Project Manager v77

## Deployment Package

**Version:** v77
**Build Date:** 2026-02-21
**New in v77:** Popup Login System for External Websites

---

## What's New in v77

- **Popup Login Page** (`login.php`) - Standalone login with OCF branding
- **Embed Script** (`login-embed.js`) - Add login to any external website
- **Demo Documentation** (`login-demo.html`) - Integration examples
- **Password Setup** (`api/setup_passwords.php`) - Configure demo user passwords

---

## Quick Setup

### 1. Upload Files
Upload all files from this package to your web server root.

### 2. Configure Database
Edit `api/config.php` with your database credentials:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'gantt_project_manager');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
```

### 3. Run SQL Scripts
Execute in order via phpMyAdmin or command line:
```bash
mysql -u username -p database_name < sql/schema.sql
mysql -u username -p database_name < sql/seed.sql
mysql -u username -p database_name < sql/templates_schema.sql
mysql -u username -p database_name < sql/migrate_project1_to_template.sql  # Optional
```

### 4. Setup Demo Passwords
Visit in browser: `https://your-domain.com/api/setup_passwords.php`

### 5. Test Login
Visit: `https://your-domain.com/login.php`

### 6. Verify Deployment
Visit: `https://your-domain.com/api/full_verify.php`

### 7. Delete Setup Scripts
Remove these files after verification:
- `api/full_verify.php`
- `api/db_verify.php`
- `api/file_verify.php`
- `api/version_verify.php`
- `api/setup_passwords.php`

---

## Demo User Credentials

| Role    | Email                              | Password    |
|---------|---------------------------------------|-------------|
| Admin   | admin@oasiscapitalfinance.com      | admin123    |
| Manager | sarah@oasiscapitalfinance.com      | manager123  |
| Manager | michael@oasiscapitalfinance.com    | manager123  |
| Client  | contact@acmecorp.com               | client123   |
| Client  | info@globalinvest.com              | client123   |
| Client  | hello@techventures.com             | client123   |

---

## Adding Login to External Websites

### Option 1: Auto-generate Button
```html
<div id="gantt-login-button"></div>
<script src="https://YOUR-DOMAIN.com/login-embed.js" data-target="gantt-login-button"></script>
```

### Option 2: Custom Link/Button
```html
<a href="#" onclick="GanttLogin.open(); return false;">Login to Project Manager</a>
<script src="https://YOUR-DOMAIN.com/login-embed.js"></script>
```

### Option 3: Direct Link (No JavaScript)
```html
<a href="https://YOUR-DOMAIN.com/login.php" target="_blank">Login to Project Manager</a>
```

### Option 4: Popup Window
```html
<a href="https://YOUR-DOMAIN.com/login.php?popup=1"
   onclick="window.open(this.href, 'GanttLogin', 'width=450,height=650'); return false;">
   Login (Popup)
</a>
```

---

## File Structure

```
/
├── index.html              # Main application
├── 404.html                # Error page
├── login.php               # Popup login page (v77)
├── login-embed.js          # Embed script (v77)
├── login-demo.html         # Documentation (v77)
├── .htaccess               # Apache configuration
│
├── api/
│   ├── config.php          # Database configuration
│   ├── projects.php        # Projects API
│   ├── tasks.php           # Tasks API
│   ├── templates.php       # Templates API
│   ├── comments.php        # Comments API
│   ├── auth.php            # Authentication API
│   ├── statistics.php      # Statistics API
│   ├── full_verify.php     # Full verification (DELETE after use)
│   ├── setup_passwords.php # Password setup (DELETE after use)
│   └── ...                 # Other verification scripts
│
├── sql/
│   ├── schema.sql          # Core database schema
│   ├── seed.sql            # Sample data
│   ├── templates_schema.sql # Template tables
│   └── migrate_project1_to_template.sql
│
├── images/
│   └── logo/               # Logo files
│
└── _next/
    └── static/             # CSS, JS, fonts
```

---

## API Endpoints

| Endpoint           | Method | Description                    |
|--------------------|--------|--------------------------------|
| `/api/projects`    | GET    | List all projects              |
| `/api/projects`    | POST   | Create project (with template) |
| `/api/tasks`       | GET    | List tasks for project         |
| `/api/tasks`       | POST   | Create task                    |
| `/api/templates`   | GET    | List templates                 |
| `/api/auth?action=login` | POST | User login              |
| `/api/auth?action=logout` | POST | User logout             |
| `/api/auth?action=me` | GET | Get current user              |

---

## Troubleshooting

### "Invalid credentials" on login
Run `/api/setup_passwords.php` to configure demo passwords.

### Templates not showing in "Create Project"
Run `sql/templates_schema.sql` and optionally `sql/migrate_project1_to_template.sql`.

### API returns 404
- Ensure `.htaccess` is uploaded
- Enable Apache mod_rewrite
- Check file permissions (755 for folders, 644 for files)

### Session not persisting
- Check PHP session configuration
- Ensure cookies are enabled
- For cross-domain, configure CORS in `config.php`

---

## Support

For issues or questions, contact: admin@oasiscapitalfinance.com

---

## Version History

- **v77** - Popup login system for external websites
- **v76** - Fixed API URLs (relative paths)
- **v75** - Version verification scripts
- **v50** - Template system

---

&copy; 2026 Oasis Capital Finance. All rights reserved.
