# Gantt Project Manager - Deployment Package

## Version: v75
**Build Date:** 2026-02-20

---

## Quick Start

1. **Upload all files** from this package to your web server
2. **Edit** `api/config.php` with your database credentials
3. **Run SQL scripts** in order (see Database Setup below)
4. **Verify deployment** by visiting `https://yourdomain.com/api/version_verify.php`
5. **Delete verification files** after confirming everything works

---

## Package Contents

```
deployment/
├── index.html              # Main application (v75)
├── 404.html                # Error page (v75)
├── .htaccess               # Apache rewrite rules
├── README.md               # This file
│
├── api/                    # PHP Backend (v75)
│   ├── config.php          # Database configuration ⚙️
│   ├── projects.php        # Projects API
│   ├── tasks.php           # Tasks API
│   ├── templates.php       # Templates API
│   ├── comments.php        # Comments API
│   ├── auth.php            # Authentication API
│   ├── statistics.php      # Statistics API
│   ├── version_verify.php  # Version verification (DELETE AFTER USE)
│   ├── db_verify.php       # Database verification (DELETE AFTER USE)
│   └── file_verify.php     # File verification (DELETE AFTER USE)
│
├── sql/                    # Database Scripts (v75)
│   ├── schema.sql          # Core tables (run first)
│   ├── seed.sql            # Sample data (run second)
│   ├── templates_schema.sql # Template tables (run third)
│   ├── migrate_project1_to_template.sql # OCF template (optional)
│   └── update_users.sql    # Sync users (if needed)
│
├── _next/                  # Frontend assets
│   └── static/
│       ├── css/            # Stylesheets
│       ├── chunks/         # JavaScript
│       └── media/          # Fonts
│
└── images/
    └── logo/               # Logo images
```

---

## Database Configuration

Edit `api/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_password');
```

---

## Database Setup

Run these SQL scripts in order:

### Fresh Installation
```bash
mysql -u username -p database_name < sql/schema.sql
mysql -u username -p database_name < sql/seed.sql
mysql -u username -p database_name < sql/templates_schema.sql
mysql -u username -p database_name < sql/migrate_project1_to_template.sql  # Optional
```

### Or via phpMyAdmin
1. Import `schema.sql`
2. Import `seed.sql`
3. Import `templates_schema.sql`
4. Import `migrate_project1_to_template.sql` (optional)

---

## Version Verification

After deployment, visit:

```
https://yourdomain.com/api/version_verify.php
```

This script will check:
- ✅ All files have v75 version markers
- ✅ Database connection works
- ✅ Required tables exist
- ✅ API endpoints respond correctly
- ✅ Static assets are present

**⚠️ Delete verification files after confirming deployment:**
```
api/version_verify.php
api/db_verify.php
api/file_verify.php
api/db_test.php
api/debug.php
api/test_api.php
api/test_create.php
```

---

## Version Markers

All files in this package contain version markers for verification:

| File Type | Marker Format |
|-----------|---------------|
| PHP Files | `@version v75` in docblock |
| SQL Files | `-- Version: v75` header |
| HTML Files | `data-gpm-version="v75"` attribute |
| API Responses | `"version": "v75"` in JSON |
| HTTP Headers | `X-GPM-Version: v75` |

---

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/projects.php` | GET | List all projects |
| `/api/projects.php?id=1` | GET | Get single project |
| `/api/projects.php` | POST | Create project |
| `/api/tasks.php?project_id=1` | GET | Get tasks for project |
| `/api/tasks.php` | POST | Create task |
| `/api/templates.php` | GET | List templates |
| `/api/statistics.php?project_id=1` | GET | Get project stats |

---

## User Roles

| Role | Permissions |
|------|-------------|
| `admin` | Full access, manage templates |
| `manager` | Create projects, manage tasks |
| `member` | Edit assigned tasks |
| `viewer` | Read-only access |
| `client` | View allocated projects only |

---

## Default Login

After running `seed.sql`:

| Username | Password | Role |
|----------|----------|------|
| admin | password123 | Admin |
| sarah.johnson | password123 | Manager |

---

## Troubleshooting

### 500 Internal Server Error
- Check PHP error logs
- Verify `config.php` credentials
- Ensure PDO MySQL extension is enabled

### API returns 404
- Check `.htaccess` is uploaded
- Verify Apache mod_rewrite is enabled
- Check file permissions (644 for files, 755 for directories)

### Database connection fails
- Verify database host, name, user, password
- Check MySQL/MariaDB is running
- Ensure user has SELECT, INSERT, UPDATE, DELETE permissions

### Version verification fails
- Re-upload files from this package
- Ensure you're using the v75 deployment package
- Check that file contents weren't modified during transfer

---

## Support

- **Documentation:** https://docs.same.new
- **Support:** support@same.new
- **Version:** v75 (Build: 2026-02-20)

---

## Changelog

### v75 (2026-02-20)
- Added version markers to all files
- Created comprehensive version_verify.php
- All API responses include version number
- HTTP headers include X-GPM-Version
- Improved error handling

### Previous Versions
- v51: Database verification script
- v50: Template system complete
- v45: Template management UI
- v44: Project templates

---

**Package:** `gantt-project-manager-v75-deployment.zip`
**Version:** v75
**Build:** 2026-02-20
