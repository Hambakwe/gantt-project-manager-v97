# Gantt Project Manager v37 - Deployment Package

A professional Gantt chart project management application with multi-user support, task comments, and full database integration.

## What's New in v37

- **Full API Integration**: Frontend now connects directly to PHP API
- **Real-time Database Sync**: All changes saved to MySQL immediately
- **Loading States**: Visual feedback during API operations
- **Comments via API**: Comments stored in database with user attribution

## What's New in v36

- **User Authentication**: Login/selection UI with role-based permissions
- **Multi-Project Support**: Create and switch between multiple projects
- **Client Allocation**: Assign projects to clients for read-only viewing
- **Task Comments**: Add comments and notes to tasks with user attribution
- **Undo/Redo**: Full undo/redo functionality (Ctrl+Z/Y)
- **Project-Scoped Storage**: Each project has isolated task data

## User Roles

| Role | Permissions |
|------|-------------|
| **Admin** | Full access to all features and settings |
| **Manager** | Create projects, manage tasks, allocate clients |
| **Client** | View allocated projects only (read-only) |

## Directory Structure

```
deployment/
├── index.html          # Main application
├── _next/              # Next.js static assets
├── api/                # PHP 8.x API endpoints
│   ├── config.php      # Database configuration
│   ├── tasks.php       # Tasks CRUD API
│   ├── projects.php    # Projects CRUD API
│   ├── comments.php    # Task comments API (NEW)
│   ├── auth.php        # Authentication API
│   └── statistics.php  # Statistics API
├── sql/
│   ├── schema.sql      # Full database schema (v36)
│   ├── seed.sql        # Demo data with users
│   └── v36_migration.sql # Migration from older versions
├── images/
│   └── logo/           # Logo files
├── .htaccess           # Apache URL rewriting
└── .env.example        # Environment configuration template
```

## Requirements

- **Web Server**: Apache 2.4+ with mod_rewrite OR Nginx
- **PHP**: 8.0 or higher
- **Database**: MySQL 5.7+ / MariaDB 10.2+
- **PHP Extensions**: PDO, pdo_mysql, mbstring, json

## Installation

### 1. Upload Files

Upload all files to your web server's document root or a subdirectory.

### 2. Create Database

```bash
mysql -u root -p < sql/schema.sql
mysql -u root -p < sql/seed.sql
```

### 3. Configure Environment

Copy `.env.example` to `.env` and update:

```env
DB_HOST=localhost
DB_NAME=gantt_project_manager
DB_USER=your_db_user
DB_PASS=your_db_password
```

Or edit `api/config.php` directly.

### 4. Set Permissions

```bash
chmod 755 api/
chmod 644 api/*.php
```

### 5. Configure Apache (if needed)

Ensure `.htaccess` is enabled:

```apache
<Directory /path/to/gantt>
    AllowOverride All
    Require all granted
</Directory>
```

## Upgrading from Previous Versions

If upgrading from a previous version, run the migration script:

```bash
mysql -u root -p gantt_project_manager < sql/v36_migration.sql
```

This adds:
- `notes` field to tasks
- `client_id` and `client_name` fields to projects
- `client` role to users
- `user_name` field to task_comments
- Demo client users

## API Endpoints

### Tasks
- `GET /api/tasks.php?project_id=1` - List tasks
- `GET /api/tasks.php?id=1` - Get single task
- `POST /api/tasks.php` - Create task
- `PUT /api/tasks.php?id=1` - Update task
- `DELETE /api/tasks.php?id=1` - Delete task

### Projects
- `GET /api/projects.php` - List all projects
- `GET /api/projects.php?client_id=101` - List client's projects
- `POST /api/projects.php` - Create project
- `PUT /api/projects.php?id=1` - Update project (including client allocation)

### Comments (NEW in v36)
- `GET /api/comments.php?task_id=1` - Get task comments
- `POST /api/comments.php` - Add comment
- `PUT /api/comments.php?id=1` - Update comment
- `DELETE /api/comments.php?id=1` - Delete comment

## Demo Users

| Username | Email | Role | Password |
|----------|-------|------|----------|
| admin | admin@oasiscapitalfinance.com | Admin | password123 |
| sarah.johnson | sarah@oasiscapitalfinance.com | Manager | password123 |
| michael.chen | michael@oasiscapitalfinance.com | Manager | password123 |
| acme_corp | contact@acmecorp.com | Client | password123 |
| global_invest | info@globalinvest.com | Client | password123 |
| tech_ventures | hello@techventures.com | Client | password123 |

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `1` / `2` / `3` | Day / Week / Month zoom |
| `Ctrl+N` | New task |
| `Ctrl+Z` | Undo |
| `Ctrl+Shift+Z` / `Ctrl+Y` | Redo |
| `Ctrl+D` | Toggle dependencies |
| `Ctrl+K` | Toggle critical path |

## Troubleshooting

### CORS Issues
Ensure your API config allows cross-origin requests:
```php
header('Access-Control-Allow-Origin: *');
```

### Database Connection
Test connection:
```php
<?php
require_once 'api/config.php';
$db = Database::getInstance();
echo "Connected successfully";
```

### 404 Errors
Check that `.htaccess` rules are active and mod_rewrite is enabled.

## License

MIT License - See LICENSE file for details.

## Support

For issues or questions, contact: support@oasiscapitalfinance.com
