<?php
/**
 * Database Connection Test Script
 * Upload to /api/db_test.php and access via browser
 * DELETE THIS FILE AFTER TESTING - contains sensitive info
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database credentials
$host = 'localhost';
$dbname = 'oasiscapfin_gantt_project_manager';
$username = 'oasiscapfin_ganttuser';
$password = 'C1nd3r3ll4!$';
$charset = 'utf8mb4';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html><html><head><title>Database Test</title>";
echo "<style>
body { font-family: Arial, sans-serif; max-width: 1200px; margin: 20px auto; padding: 20px; }
h1 { color: #14b8a6; }
h2 { color: #57534e; margin-top: 30px; border-bottom: 2px solid #e7e5e4; padding-bottom: 10px; }
.success { color: #16a34a; background: #dcfce7; padding: 10px; border-radius: 5px; }
.error { color: #dc2626; background: #fef2f2; padding: 10px; border-radius: 5px; }
.warning { color: #d97706; background: #fef3c7; padding: 10px; border-radius: 5px; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #d6d3d1; padding: 8px; text-align: left; }
th { background: #f5f5f4; }
tr:nth-child(even) { background: #fafaf9; }
code { background: #f5f5f4; padding: 2px 6px; border-radius: 3px; font-family: monospace; }
pre { background: #1c1917; color: #fafaf9; padding: 15px; border-radius: 5px; overflow-x: auto; }
</style></head><body>";

echo "<h1>🔍 Database Connection Test</h1>";
echo "<p><strong>Time:</strong> " . date('Y-m-d H:i:s') . "</p>";

// Connection details (masked password)
echo "<h2>1. Connection Details</h2>";
echo "<table>";
echo "<tr><th>Setting</th><th>Value</th></tr>";
echo "<tr><td>Host</td><td><code>$host</code></td></tr>";
echo "<tr><td>Database</td><td><code>$dbname</code></td></tr>";
echo "<tr><td>Username</td><td><code>$username</code></td></tr>";
echo "<tr><td>Password</td><td><code>" . str_repeat('*', strlen($password)) . "</code> (" . strlen($password) . " chars)</td></tr>";
echo "<tr><td>Charset</td><td><code>$charset</code></td></tr>";
echo "</table>";

// Test connection
echo "<h2>2. Connection Test</h2>";

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $pdo = new PDO($dsn, $username, $password, $options);

    echo "<p class='success'>✅ <strong>Connection successful!</strong></p>";

    // Server info
    $serverInfo = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
    echo "<p><strong>MySQL Version:</strong> $serverInfo</p>";

} catch (PDOException $e) {
    echo "<p class='error'>❌ <strong>Connection failed:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";

    // Troubleshooting tips
    echo "<h3>Troubleshooting:</h3>";
    echo "<ul>";
    echo "<li>Check if the database <code>$dbname</code> exists</li>";
    echo "<li>Verify username <code>$username</code> has access to this database</li>";
    echo "<li>Check if the password is correct</li>";
    echo "<li>Ensure MySQL server is running</li>";
    echo "</ul>";

    echo "</body></html>";
    exit;
}

// List tables
echo "<h2>3. Database Tables</h2>";

$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

if (empty($tables)) {
    echo "<p class='warning'>⚠️ <strong>No tables found!</strong> You need to run the SQL schema.</p>";
    echo "<p>Run these commands:</p>";
    echo "<pre>mysql -u $username -p $dbname < sql/schema.sql\nmysql -u $username -p $dbname < sql/seed.sql</pre>";
} else {
    echo "<p class='success'>✅ Found <strong>" . count($tables) . "</strong> tables</p>";

    echo "<table>";
    echo "<tr><th>Table Name</th><th>Row Count</th><th>Status</th></tr>";

    foreach ($tables as $table) {
        $count = $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
        $status = $count > 0 ? "✅ Has data" : "⚠️ Empty";
        echo "<tr><td><code>$table</code></td><td>$count</td><td>$status</td></tr>";
    }
    echo "</table>";
}

// Check specific tables
echo "<h2>4. Table Contents</h2>";

$requiredTables = ['users', 'projects', 'tasks', 'task_comments', 'task_dependencies'];

foreach ($requiredTables as $tableName) {
    echo "<h3>Table: <code>$tableName</code></h3>";

    if (!in_array($tableName, $tables)) {
        echo "<p class='error'>❌ Table does not exist!</p>";
        continue;
    }

    // Get row count
    $count = $pdo->query("SELECT COUNT(*) FROM `$tableName`")->fetchColumn();

    if ($count == 0) {
        echo "<p class='warning'>⚠️ Table is empty</p>";
        continue;
    }

    // Show sample data (first 5 rows)
    echo "<p>Showing first 5 of $count rows:</p>";

    $stmt = $pdo->query("SELECT * FROM `$tableName` LIMIT 5");
    $rows = $stmt->fetchAll();

    if (!empty($rows)) {
        echo "<table>";
        echo "<tr>";
        foreach (array_keys($rows[0]) as $col) {
            echo "<th>" . htmlspecialchars($col) . "</th>";
        }
        echo "</tr>";

        foreach ($rows as $row) {
            echo "<tr>";
            foreach ($row as $value) {
                $displayValue = $value;
                if (strlen($value) > 50) {
                    $displayValue = substr($value, 0, 47) . '...';
                }
                echo "<td>" . htmlspecialchars($displayValue ?? 'NULL') . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    }
}

// Test API endpoints
echo "<h2>5. Quick API Test</h2>";

echo "<p>Test these endpoints in your browser:</p>";
echo "<ul>";
echo "<li><a href='projects.php' target='_blank'>projects.php</a> - Should return JSON with projects</li>";
echo "<li><a href='tasks.php?project_id=1' target='_blank'>tasks.php?project_id=1</a> - Should return tasks for project 1</li>";
echo "<li><a href='statistics.php?project_id=1' target='_blank'>statistics.php?project_id=1</a> - Should return project statistics</li>";
echo "</ul>";

// Check for common issues
echo "<h2>6. Common Issues Check</h2>";

$issues = [];

// Check if projects table has data
if (in_array('projects', $tables)) {
    $projectCount = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    if ($projectCount == 0) {
        $issues[] = "No projects in database - run seed.sql";
    }
}

// Check if users table has data
if (in_array('users', $tables)) {
    $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($userCount == 0) {
        $issues[] = "No users in database - run seed.sql";
    }
}

// Check if tasks table has data
if (in_array('tasks', $tables)) {
    $taskCount = $pdo->query("SELECT COUNT(*) FROM tasks")->fetchColumn();
    if ($taskCount == 0) {
        $issues[] = "No tasks in database - run seed.sql";
    }
}

if (empty($issues)) {
    echo "<p class='success'>✅ No obvious issues found!</p>";
} else {
    echo "<ul>";
    foreach ($issues as $issue) {
        echo "<li class='warning'>⚠️ $issue</li>";
    }
    echo "</ul>";
}

// SQL to run
echo "<h2>7. SQL Commands to Populate Database</h2>";
echo "<p>If tables are empty, run these SQL files:</p>";
echo "<pre>";
echo "# Connect to MySQL\n";
echo "mysql -u $username -p\n\n";
echo "# Select database\n";
echo "USE $dbname;\n\n";
echo "# Check if tables exist\n";
echo "SHOW TABLES;\n\n";
echo "# If no tables, run schema.sql first\n";
echo "SOURCE /path/to/sql/schema.sql;\n\n";
echo "# Then run seed.sql to add demo data\n";
echo "SOURCE /path/to/sql/seed.sql;\n";
echo "</pre>";

echo "<hr>";
echo "<p style='color: #dc2626;'><strong>⚠️ SECURITY WARNING:</strong> Delete this file after testing! It exposes database credentials.</p>";

echo "</body></html>";
