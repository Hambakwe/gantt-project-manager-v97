<?php
/**
 * Test API Response Format
 * Visit: /api/test_api.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/config.php';

$results = array();

// Test 1: Direct database query
try {
    $db = Database::getInstance();
    $stmt = $db->query('SELECT * FROM projects WHERE is_active = 1');
    $projects = $stmt->fetchAll();
    $results['direct_query'] = array(
        'success' => true,
        'count' => count($projects),
        'projects' => $projects
    );
} catch (Exception $e) {
    $results['direct_query'] = array(
        'success' => false,
        'error' => $e->getMessage()
    );
}

// Test 2: Simulate what projects.php getProjects() does
try {
    $db = Database::getInstance();
    $stmt = $db->query('
        SELECT
            p.*,
            u.full_name as owner_name,
            c.full_name as client_display_name,
            COUNT(DISTINCT t.id) as task_count,
            COUNT(DISTINCT CASE WHEN t.status = "complete" THEN t.id END) as completed_count,
            COALESCE(AVG(t.progress), 0) as avg_progress
        FROM projects p
        LEFT JOIN users u ON p.owner_id = u.id
        LEFT JOIN users c ON p.client_id = c.id
        LEFT JOIN tasks t ON p.id = t.project_id
        WHERE p.is_active = 1
        GROUP BY p.id
        ORDER BY p.updated_at DESC
    ');
    $projects = $stmt->fetchAll();

    // Format like the API does
    $formattedProjects = array();
    foreach ($projects as $project) {
        $formattedProjects[] = array(
            'id' => (int)$project['id'],
            'name' => $project['name'],
            'description' => $project['description'],
            'color' => $project['color'],
            'owner_id' => $project['owner_id'] ? (int)$project['owner_id'] : null,
            'owner_name' => $project['owner_name'],
            'client_id' => $project['client_id'] ? (int)$project['client_id'] : null,
            'client_name' => $project['client_name'],
            'is_active' => (bool)$project['is_active'],
            'task_count' => (int)$project['task_count'],
            'completed_count' => (int)$project['completed_count'],
            'avg_progress' => round((float)$project['avg_progress'], 1),
            'created_at' => $project['created_at'],
            'updated_at' => $project['updated_at']
        );
    }

    $results['formatted_projects'] = array(
        'success' => true,
        'data' => $formattedProjects
    );

} catch (Exception $e) {
    $results['formatted_projects'] = array(
        'success' => false,
        'error' => $e->getMessage()
    );
}

// Test 3: What the frontend expects
$results['frontend_expects'] = array(
    'format' => '{ success: true, data: [ { id, name, description, ... } ] }',
    'note' => 'The frontend looks for response.data array'
);

echo json_encode($results, JSON_PRETTY_PRINT);
