<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

require_once __DIR__ . '/config.php';

$results = array(
    'timestamp' => date('Y-m-d H:i:s'),
    'php_version' => PHP_VERSION
);

try {
    $db = Database::getInstance();
    $results['db_connected'] = true;

    $projects = $db->query('SELECT * FROM projects')->fetchAll();
    $results['projects_count'] = count($projects);
    $results['projects'] = $projects;

    $tasks = $db->query('SELECT * FROM tasks LIMIT 5')->fetchAll();
    $results['tasks_count'] = count($tasks);
    $results['tasks_sample'] = $tasks;

    $users = $db->query('SELECT id, username, full_name, role FROM users')->fetchAll();
    $results['users_count'] = count($users);
    $results['users'] = $users;

} catch (Exception $e) {
    $results['error'] = $e->getMessage();
}

echo json_encode($results, JSON_PRETTY_PRINT);
