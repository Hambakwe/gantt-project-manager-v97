<?php
/**
 * Test Project Creation
 * Visit: /api/test_create.php
 * DELETE AFTER TESTING
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

require_once __DIR__ . '/config.php';

$results = array('timestamp' => date('Y-m-d H:i:s'));

try {
    $db = Database::getInstance();

    // Count projects before
    $countBefore = $db->query('SELECT COUNT(*) FROM projects')->fetchColumn();
    $results['projects_before'] = (int)$countBefore;

    // Create a test project
    $testName = 'TEST_PROJECT_' . time();
    $stmt = $db->prepare('INSERT INTO projects (name, description, color, owner_id, is_active) VALUES (?, ?, ?, ?, 1)');
    $stmt->execute(array($testName, 'Test description', '#14b8a6', 1));

    $newId = $db->lastInsertId();
    $results['new_project_id'] = (int)$newId;

    // Count projects after
    $countAfter = $db->query('SELECT COUNT(*) FROM projects')->fetchColumn();
    $results['projects_after'] = (int)$countAfter;

    // Get the new project
    $stmt = $db->prepare('SELECT * FROM projects WHERE id = ?');
    $stmt->execute(array($newId));
    $newProject = $stmt->fetch();
    $results['new_project'] = $newProject;

    // Delete the test project
    $db->prepare('DELETE FROM projects WHERE id = ?')->execute(array($newId));
    $results['test_project_deleted'] = true;

    $results['success'] = true;
    $results['message'] = 'Project creation works! The database can INSERT new projects.';

} catch (Exception $e) {
    $results['success'] = false;
    $results['error'] = $e->getMessage();
}

echo json_encode($results, JSON_PRETTY_PRINT);
